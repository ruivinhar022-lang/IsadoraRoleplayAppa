Projeto Android minimal para ISADORA ROLEPLAY
Abra no Android Studio: IsadoraRoleplayApp/
Imagem splash: app/src/main/res/drawable/splash_image.png
Edite strings.xml para alterar IP/DATA.
