package com.isadora.roleplay

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvName = findViewById<TextView>(R.id.tvName)
        val tvServer = findViewById<TextView>(R.id.tvServer)
        val tvDate = findViewById<TextView>(R.id.tvDate)
        val btnCopy = findViewById<Button>(R.id.btnCopy)

        tvName.text = getString(R.string.server_name)
        tvServer.text = getString(R.string.server_ip)
        tvDate.text = getString(R.string.server_date)

        btnCopy.setOnClickListener {
            val clip = ClipData.newPlainText("server", getString(R.string.server_ip))
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(clip)
            Toast.makeText(this, "IP copiado!", Toast.LENGTH_SHORT).show()
        }
    }
}
